from __future__ import annotations

from datetime import datetime
from pathlib import Path

import pandas as pd
from flask import Flask, flash, redirect, render_template, request, url_for

from parser import InvoiceParseError, convert_pdf_to_excel


app = Flask(__name__)
app.secret_key = "invoice-tracker-secret"

BASE_DIR = Path(__file__).resolve().parent
INPUT_DIR = BASE_DIR / "input"
DATA_DIR = BASE_DIR / "data"
INVOICE_FILE = DATA_DIR / "invoice.xlsx"
WORKING_FILE = DATA_DIR / "working_invoice.xlsx"
FINAL_FILE = DATA_DIR / "finalized_invoice.xlsx"

invoice_list: list[dict] = []
scan_log: list[dict] = []



def ensure_directories() -> None:
    INPUT_DIR.mkdir(parents=True, exist_ok=True)
    DATA_DIR.mkdir(parents=True, exist_ok=True)



def to_int(value, default: int = 0) -> int:
    try:
        if value is None or value == "":
            return default
        return int(value)
    except (ValueError, TypeError):
        return default



def newest_pdf() -> Path | None:
    pdfs = sorted(INPUT_DIR.glob("*.pdf"), key=lambda path: path.stat().st_mtime, reverse=True)
    return pdfs[0] if pdfs else None



def import_latest_pdf() -> tuple[Path, int]:
    pdf_path = newest_pdf()
    if pdf_path is None:
        raise FileNotFoundError(f"No PDF found in {INPUT_DIR}")
    return convert_pdf_to_excel(pdf_path, INVOICE_FILE)



def load_invoice() -> None:
    global invoice_list
    ensure_directories()

    if not WORKING_FILE.exists() and not INVOICE_FILE.exists():
        import_latest_pdf()

    source_file = WORKING_FILE if WORKING_FILE.exists() else INVOICE_FILE
    records = pd.read_excel(source_file).fillna("").to_dict(orient="records")

    for item in records:
        item["UPC"] = str(item.get("UPC", "")).strip()
        item["Desc"] = str(item.get("Desc", "")).strip()
        item["DRQty"] = to_int(item.get("DRQty", 0))
        item["ScanQty"] = to_int(item.get("ScanQty", 0))

    invoice_list = records



def save_working_file() -> None:
    pd.DataFrame(invoice_list, columns=["UPC", "Desc", "DRQty", "ScanQty"]).to_excel(WORKING_FILE, index=False)



def save_final_file() -> None:
    final_records = []
    for item in invoice_list:
        row = dict(item)
        row["Difference"] = to_int(row.get("ScanQty", 0)) - to_int(row.get("DRQty", 0))
        final_records.append(row)

    pd.DataFrame(final_records).to_excel(FINAL_FILE, index=False)



def find_item_by_upc(scan_upc: str):
    scan_upc = str(scan_upc).strip()
    for item in invoice_list:
        if item["UPC"] == scan_upc:
            return item
    return None



def log_scan(action: str, upc: str, message: str) -> None:
    scan_log.insert(
        0,
        {
            "time": datetime.now().strftime("%H:%M:%S"),
            "action": action,
            "upc": upc,
            "message": message,
        },
    )
    if len(scan_log) > 15:
        scan_log.pop()



def get_dashboard_stats() -> dict:
    total_items = len(invoice_list)
    total_expected = sum(to_int(item.get("DRQty", 0)) for item in invoice_list)
    total_scanned = sum(to_int(item.get("ScanQty", 0)) for item in invoice_list)
    matched_items = sum(1 for item in invoice_list if to_int(item.get("ScanQty", 0)) == to_int(item.get("DRQty", 0)))
    return {
        "total_items": total_items,
        "total_expected": total_expected,
        "total_scanned": total_scanned,
        "matched_items": matched_items,
    }


@app.route("/", methods=["GET"])
def index():
    last_item = None
    last_upc = request.args.get("last_upc", "").strip()
    if last_upc:
        last_item = find_item_by_upc(last_upc)

    stats = get_dashboard_stats()
    return render_template(
        "index.html",
        last_item=last_item,
        last_upc=last_upc,
        scan_log=scan_log,
        pdf_name=(newest_pdf().name if newest_pdf() else "No PDF found"),
        invoice_file=INVOICE_FILE.name if INVOICE_FILE.exists() else "No invoice loaded",
        **stats,
    )


@app.route("/scan", methods=["POST"])
def scan():
    upc = request.form.get("upc", "").strip()
    action = request.form.get("action", "add").strip()

    if not upc:
        flash("No UPC entered.")
        return redirect(url_for("index"))

    item = find_item_by_upc(upc)
    if item is None:
        flash(f"UPC not found: {upc}")
        log_scan(action, upc, "UPC not found")
        return redirect(url_for("index", last_upc=upc))

    if action == "remove":
        item["ScanQty"] = max(0, to_int(item.get("ScanQty", 0)) - 1)
        message = f"Removed 1 from {item['Desc']}. ScanQty = {item['ScanQty']}"
    else:
        item["ScanQty"] = to_int(item.get("ScanQty", 0)) + 1
        message = f"Added 1 to {item['Desc']}. ScanQty = {item['ScanQty']}"

    save_working_file()
    flash(message)
    log_scan(action, upc, message)
    return redirect(url_for("index", last_upc=upc))


@app.route("/finalize", methods=["POST"])
def finalize():
    save_final_file()
    flash(f"Finalized file saved as {FINAL_FILE.name}")
    return redirect(url_for("index"))


@app.route("/reset", methods=["POST"])
def reset_counts():
    for item in invoice_list:
        item["ScanQty"] = 0
    save_working_file()
    flash("All ScanQty values reset to 0.")
    return redirect(url_for("index"))


@app.route("/reload-pdf", methods=["POST"])
def reload_pdf():
    global invoice_list
    try:
        pdf_path, count = import_latest_pdf()
        if WORKING_FILE.exists():
            WORKING_FILE.unlink()
        load_invoice()
        flash(f"Imported {count} rows from {pdf_path.name}")
    except (FileNotFoundError, InvoiceParseError, ValueError) as exc:
        flash(f"PDF import failed: {exc}")
    return redirect(url_for("index"))


if __name__ == "__main__":
    ensure_directories()
    try:
        load_invoice()
    except (FileNotFoundError, InvoiceParseError, ValueError) as exc:
        print(f"Startup warning: {exc}")
    app.run(host="0.0.0.0", port=5000, debug=False)
