# Invoice Tracker

A local Flask app for barcode-based invoice reconciliation.

## Folder layout

- `input/` — drop invoice PDFs here
- `data/` — generated Excel files are written here
- `templates/` — Flask HTML template
- `parser.py` — converts the PDF invoice into `invoice.xlsx`
- `app.py` — runs the scanner web app

## Expected workflow

1. Put the invoice PDF into the `input` folder.
2. Run `python app.py`.
3. Open `http://127.0.0.1:5000` on the laptop, or `http://<laptop-ip>:5000` from the Zebra when both are on the same network.
4. Scan UPCs to increment or decrement counts.
5. Click **Finalize Excel** to create `data/finalized_invoice.xlsx`.

## Install

```bash
pip install -r requirements.txt
```

## Notes

- The parser is intentionally tailored to the exact Loblaws invoice layout you provided.
- If you drop in a newer invoice PDF with the same layout, click **Import latest PDF**.
- The generated workbook columns are `UPC`, `Desc`, `DRQty`, and `ScanQty`.
